1.进入32X交换机

cd /home后新建项目文件夹，比如命名为xjjs

2.将scx.tar.gz解压

2.1  bash compile.sh 编译regex.p4文件，转发端口的配置在common中typeandheaders.p4文件

2.2 bash install.sh 会自动将regex.p4程序下载下去

2.3 bash set_port.sh 会设置两个物理端口（目前是15和16）用于接收数据包和发送数据包，然后通过pm.show等方式观察接收和转发的数据

注意：1.推荐使用思博伦收发数据，如果用dpdk，前面文件目录中的ids_test_packet.pacp文件，实验感觉它不是按顺序发送的，导致实际转发的100个包本来应该10个包，总是有一点出入，但是代码如果我没有找错应该没问题，我之前都在硬件模拟中跑过。

2.为了方便，在吞吐量测试时候，没有下发表条目，直接在代码中内置了const的表条目。