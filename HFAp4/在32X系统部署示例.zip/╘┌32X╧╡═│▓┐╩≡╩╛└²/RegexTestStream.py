from scapy.all import IP, UDP, Raw,  Ether,wrpcap
import random
import string
import os
# 目标和源的 IP 地址和端口
destination_ip = "192.168.1.1"
destination_port = 80
source_ip = "192.168.1.100"
source_port = 12345
# MAC 地址
source_mac = "02:00:00:00:00:01"
destination_mac = "02:00:00:00:00:02"
# 定义一系列特定模式的 payload 基础
base_payload_patterns = [
    "normal data",          # 正常数据
    "normal data",          # 正常数据
    "bcacac55aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",# SQL 注入攻击模拟
    "bmtmm555",    # XSS 攻击脚本模拟
    "admin5555",      # 缓冲区溢出模拟
    "normal data",          # 另一些正常数据
    "normal data",          # 正常数据
    "123tttt" ,# 恶意软件数据泄露模拟
    "normal data",          # 正常数据
    "12345tt" # 恶意软件数据泄露模拟
]

# 列表用于存储所有数据包
packets = []

for i, base_payload in enumerate(base_payload_patterns):
    # 创建以太网层
    eth_layer = Ether(src=source_mac, dst=destination_mac)
    # 创建 IP 层
    ip_layer = IP(src=source_ip, dst=destination_ip)

    # 创建 UDP 层
    udp_layer = UDP(sport=source_port, dport=destination_port)

    # 生成随机数据，确保总负载长度为 200 bytes
    #random_payload = ''.join(random.choices(string.ascii_letters + string.digits, k=200-len(base_payload)))
    length_of_random_payload = 200 - len(base_payload)  # 计算随机有效载荷的长度

# 生成只包含 '\xEE' 的字符串
    random_payload = 'E' * length_of_random_payload
    full_payload =random_payload+base_payload 

    # 使用 Raw 层来包含自定义 Payload
    payload = Raw(load=full_payload)

    # 组装完整的数据包
    packet = eth_layer /ip_layer / udp_layer / payload
    
    # 添加到数据包列表
    packets.append(packet)

# 保存所有数据包到 pcap 文件

# 获取当前脚本的绝对路径
script_path = os.path.abspath(__file__)

# 获取脚本所在目录
script_dir = os.path.dirname(script_path)
# 定义文件名
filename = 'ids_test_packets.pcap'

# 将目录路径和文件名结合形成完整的文件路径
full_file_path = os.path.join(script_dir, filename)
try:
    wrpcap(full_file_path, packets)
    print(f"文件已成功保存到 {full_file_path}")
except PermissionError:
    print("权限错误：没有写入文件的权限。")
except Exception as e:
    print(f"发生错误：{e}")